
// Message
function closeBtn() {
    document.getElementById("e_message").style.display = "none";
}